//
//  RootViewController.h
//  CocosWhackMole
//
//  Created by 欧 on 11/05/16.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
